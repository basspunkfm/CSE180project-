from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='human_detection',
            executable='human_detection_controller',
            name='human_detection_controller',
            output='screen',
            parameters=[{
                'use_sim_time': True
            }]
        )
    ])
