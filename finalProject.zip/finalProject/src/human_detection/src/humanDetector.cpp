#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <nav2_msgs/action/navigate_to_pose.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <cmath>
#include <vector>
#include <algorithm>
#include <chrono>
#include <utility>  // for std::pair

class HumanDetectionController : public rclcpp::Node
{
public:
    using NavigateToPose = nav2_msgs::action::NavigateToPose;
    using GoalHandleNavigateToPose = rclcpp_action::ClientGoalHandle<NavigateToPose>;

    HumanDetectionController() : Node("human_detection_controller")
    {
        // QoS for latched topics (map + amcl pose)
        auto qos_map  = rclcpp::QoS(rclcpp::KeepLast(1)).reliable().transient_local();
        auto qos_amcl = rclcpp::QoS(rclcpp::KeepLast(10)).reliable().transient_local();

        // Subscribers
        map_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
            "/map",
            qos_map,
            std::bind(&HumanDetectionController::mapCallback, this, std::placeholders::_1));

        scan_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
            "/scan",
            10,
            std::bind(&HumanDetectionController::scanCallback, this, std::placeholders::_1));

        amcl_pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
            "/amcl_pose",
            qos_amcl,
            std::bind(&HumanDetectionController::amclPoseCallback, this, std::placeholders::_1));

        // Action client for navigation
        nav_action_client_ = rclcpp_action::create_client<NavigateToPose>(this, "navigate_to_pose");

        // Timer for periodic checking
        timer_ = this->create_wall_timer(
            std::chrono::seconds(2),
            std::bind(&HumanDetectionController::checkForChanges, this));

        RCLCPP_INFO(this->get_logger(), "Human Detection Controller initialized");

        initial_scan_stored_ = false;
        map_received_        = false;
        change_detected_     = false;
        investigating_       = false;
    }

private:
    void mapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
    {
        if (!map_received_) {
            map_ = *msg;
            map_received_ = true;
            RCLCPP_INFO(this->get_logger(),
                        "Map received: %d x %d, resolution: %.3f",
                        map_.info.width, map_.info.height, map_.info.resolution);
        }
    }

    void scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
    {
        current_scan_ = *msg;

        // Store initial scan as baseline once we have the map
        if (!initial_scan_stored_ && map_received_) {
            initial_scan_ = *msg;
            initial_scan_stored_ = true;
            RCLCPP_INFO(this->get_logger(), "Initial scan stored as baseline");
        }
    }

    void amclPoseCallback(const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg)
    {
        current_pose_ = msg->pose.pose;
    }

    void checkForChanges()
    {
        // Debug to confirm timer is running
        RCLCPP_INFO(this->get_logger(),
                    "Timer tick (map_received=%d, baseline=%d, investigating=%d)",
                    map_received_, initial_scan_stored_, investigating_);

        if (!initial_scan_stored_ || !map_received_ || investigating_) {
            return;
        }

        // Compare current scan with initial scan
        auto diff_info = calculateScanDifference(initial_scan_, current_scan_);
        double mean_diff    = diff_info.first;
        double frac_changed = diff_info.second;

        RCLCPP_INFO(this->get_logger(),
                    "Scan diff: mean=%.4f, frac_changed=%.4f",
                    mean_diff, frac_changed);

        // Thresholds for detecting significant changes
        const double MEAN_CHANGE_THRESHOLD = 0.0001; // 2 cm average change
        const double FRAC_CHANGE_THRESHOLD = 0.0001; // 1% of beams significantly changed

        bool change = (mean_diff > MEAN_CHANGE_THRESHOLD) ||
                      (frac_changed > FRAC_CHANGE_THRESHOLD);

        if (change && !change_detected_) {
            change_detected_ = true;
            RCLCPP_WARN(this->get_logger(),
                        "CHANGE DETECTED! Humans may have moved! "
                        "(mean=%.4f, frac=%.4f)",
                        mean_diff, frac_changed);

            // Find the location of the change
            auto change_locations = findChangeLocations();

            if (!change_locations.empty()) {
                RCLCPP_INFO(this->get_logger(),
                            "Found %zu potential human locations",
                            change_locations.size());

                // Investigate locations (for now, navigate to the first)
                investigateLocations(change_locations);
            } else {
                RCLCPP_WARN(this->get_logger(),
                            "Change detected, but no valid locations found.");
            }
        }
    }

    // Returns <mean_diff, fraction_of_beams_above_threshold>
    std::pair<double, double> calculateScanDifference(
        const sensor_msgs::msg::LaserScan & scan1,
        const sensor_msgs::msg::LaserScan & scan2)
    {
        if (scan1.ranges.empty() || scan2.ranges.empty()) {
            return {0.0, 0.0};
        }

        if (scan1.ranges.size() != scan2.ranges.size()) {
            RCLCPP_WARN(this->get_logger(),
                        "Scan size mismatch: initial=%zu current=%zu",
                        scan1.ranges.size(), scan2.ranges.size());
            return {0.0, 0.0};
        }

        double total_diff  = 0.0;
        int    valid_count = 0;
        int    changed_count = 0;

        const double BEAM_CHANGE_THRESH = 0.3; // 30 cm per-beam change

        for (size_t i = 0; i < scan1.ranges.size(); ++i) {
            if (std::isnan(scan1.ranges[i]) || std::isnan(scan2.ranges[i]) ||
                std::isinf(scan1.ranges[i]) || std::isinf(scan2.ranges[i])) {
                continue;
            }

            double diff = std::abs(scan1.ranges[i] - scan2.ranges[i]);
            total_diff += diff;
            valid_count++;

            if (diff > BEAM_CHANGE_THRESH) {
                changed_count++;
            }
        }

        double mean_diff = valid_count > 0 ? total_diff / valid_count : 0.0;
        double frac_changed = valid_count > 0
            ? static_cast<double>(changed_count) / valid_count
            : 0.0;

        return {mean_diff, frac_changed};
    }

    std::vector<geometry_msgs::msg::Point> findChangeLocations()
    {
        std::vector<geometry_msgs::msg::Point> locations;

        if (initial_scan_.ranges.empty() || current_scan_.ranges.empty()) {
            return locations;
        }

        if (initial_scan_.ranges.size() != current_scan_.ranges.size()) {
            RCLCPP_WARN(this->get_logger(),
                        "Cannot find change locations: scan size mismatch.");
            return locations;
        }

        const double SIGNIFICANT_CHANGE = 0.5; // meters

        // Get robot's current position
        double robot_x   = current_pose_.position.x;
        double robot_y   = current_pose_.position.y;
        double robot_yaw = getYawFromQuaternion(current_pose_.orientation);

        for (size_t i = 0; i < current_scan_.ranges.size(); ++i) {
            if (std::isnan(initial_scan_.ranges[i]) || std::isnan(current_scan_.ranges[i]) ||
                std::isinf(initial_scan_.ranges[i]) || std::isinf(current_scan_.ranges[i])) {
                continue;
            }

            double diff = std::abs(initial_scan_.ranges[i] - current_scan_.ranges[i]);

            if (diff > SIGNIFICANT_CHANGE) {
                double angle        = current_scan_.angle_min + i * current_scan_.angle_increment;
                double global_angle = robot_yaw + angle;
                double range        = current_scan_.ranges[i];

                geometry_msgs::msg::Point pt;
                pt.x = robot_x + range * std::cos(global_angle);
                pt.y = robot_y + range * std::sin(global_angle);
                pt.z = 0.0;

                locations.push_back(pt);
            }
        }

        // Cluster nearby points
        return clusterPoints(locations, 1.0); // cluster points within 1 meter
    }

    std::vector<geometry_msgs::msg::Point> clusterPoints(
        const std::vector<geometry_msgs::msg::Point> & points, double cluster_radius)
    {
        if (points.empty()) {
            return {};
        }

        std::vector<geometry_msgs::msg::Point> clusters;
        std::vector<bool> processed(points.size(), false);

        for (size_t i = 0; i < points.size(); ++i) {
            if (processed[i]) {
                continue;
            }

            double sum_x = points[i].x;
            double sum_y = points[i].y;
            int count    = 1;
            processed[i] = true;

            for (size_t j = i + 1; j < points.size(); ++j) {
                if (processed[j]) {
                    continue;
                }

                double dist = std::sqrt(std::pow(points[i].x - points[j].x, 2) +
                                        std::pow(points[i].y - points[j].y, 2));

                if (dist < cluster_radius) {
                    sum_x += points[j].x;
                    sum_y += points[j].y;
                    count++;
                    processed[j] = true;
                }
            }

            geometry_msgs::msg::Point cluster;
            cluster.x = sum_x / count;
            cluster.y = sum_y / count;
            cluster.z = 0.0;
            clusters.push_back(cluster);
        }

        return clusters;
    }

    void investigateLocations(const std::vector<geometry_msgs::msg::Point> & locations)
    {
        investigating_ = true;

        RCLCPP_INFO(this->get_logger(), "\n========================================");
        RCLCPP_INFO(this->get_logger(), "INVESTIGATION RESULTS:");
        RCLCPP_INFO(this->get_logger(), "========================================");
        RCLCPP_INFO(this->get_logger(), "Detected %zu human location(s):", locations.size());

        for (size_t i = 0; i < locations.size(); ++i) {
            RCLCPP_INFO(this->get_logger(),
                        "Human %zu - New Position: (x=%.2f, y=%.2f)",
                        i + 1, locations[i].x, locations[i].y);
        }
        RCLCPP_INFO(this->get_logger(), "========================================\n");

        if (!locations.empty()) {
            navigateToLocation(locations[0]);
        }
    }

    void navigateToLocation(const geometry_msgs::msg::Point & location)
    {
        if (!nav_action_client_->wait_for_action_server(std::chrono::seconds(5))) {
            RCLCPP_ERROR(this->get_logger(), "Navigation action server not available");
            return;
        }

        auto goal_msg = NavigateToPose::Goal();
        goal_msg.pose.header.frame_id = "map";
        goal_msg.pose.header.stamp    = this->now();
        goal_msg.pose.pose.position.x = location.x;
        goal_msg.pose.pose.position.y = location.y;
        goal_msg.pose.pose.orientation.w = 1.0;

        RCLCPP_INFO(this->get_logger(),
                    "Navigating to location: (%.2f, %.2f)",
                    location.x, location.y);

        auto send_goal_options = rclcpp_action::Client<NavigateToPose>::SendGoalOptions();
        send_goal_options.result_callback =
            std::bind(&HumanDetectionController::navigationResultCallback,
                      this, std::placeholders::_1);

        nav_action_client_->async_send_goal(goal_msg, send_goal_options);
    }

    void navigationResultCallback(const GoalHandleNavigateToPose::WrappedResult & result)
    {
        investigating_   = false;
        change_detected_ = false;  // allow future detections

        switch (result.code) {
        case rclcpp_action::ResultCode::SUCCEEDED:
            RCLCPP_INFO(this->get_logger(), "Navigation succeeded!");
            break;
        case rclcpp_action::ResultCode::ABORTED:
            RCLCPP_ERROR(this->get_logger(), "Navigation was aborted");
            break;
        case rclcpp_action::ResultCode::CANCELED:
            RCLCPP_ERROR(this->get_logger(), "Navigation was canceled");
            break;
        default:
            RCLCPP_ERROR(this->get_logger(), "Unknown navigation result");
            break;
        }
    }

    double getYawFromQuaternion(const geometry_msgs::msg::Quaternion & q)
    {
        double siny_cosp = 2.0 * (q.w * q.z + q.x * q.y);
        double cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z);
        return std::atan2(siny_cosp, cosy_cosp);
    }

    // Member variables
    rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr map_sub_;
    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_sub_;
    rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr amcl_pose_sub_;
    rclcpp_action::Client<NavigateToPose>::SharedPtr nav_action_client_;
    rclcpp::TimerBase::SharedPtr timer_;

    nav_msgs::msg::OccupancyGrid map_;
    sensor_msgs::msg::LaserScan initial_scan_;
    sensor_msgs::msg::LaserScan current_scan_;
    geometry_msgs::msg::Pose current_pose_;

    bool initial_scan_stored_;
    bool map_received_;
    bool change_detected_;
    bool investigating_;
};

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<HumanDetectionController>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
